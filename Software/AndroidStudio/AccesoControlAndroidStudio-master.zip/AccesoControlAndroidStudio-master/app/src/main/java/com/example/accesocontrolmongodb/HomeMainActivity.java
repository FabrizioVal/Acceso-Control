package com.example.accesocontrolmongodb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HomeMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_main);
    }
}